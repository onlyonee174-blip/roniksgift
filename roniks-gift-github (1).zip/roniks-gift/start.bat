@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python luckycs_server.py
) else (
  py -3 luckycs_server.py
)
pause
